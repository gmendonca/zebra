package matrix.util;

import java.util.ArrayList;
import java.util.Map;

public class AdjList {
	public Map<Long, ArrayList<Long>> adjList;

}
