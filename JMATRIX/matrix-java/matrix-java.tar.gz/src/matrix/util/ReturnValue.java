package matrix.util;

public class ReturnValue {
	public int value;
	public String result;
	
	public ReturnValue(int value, String result){
		this.value = value;
		this.result = result;
	}
}
