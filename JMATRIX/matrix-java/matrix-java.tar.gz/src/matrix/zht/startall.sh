./zhtserver -z zht.conf -n neighbor2.conf -p 50001 & sleep 1
./zhtserver -z zht.conf -n neighbor2.conf -p 50002 & sleep 1
./zhtserver -z zht.conf -n neighbor2.conf -p 50003 & sleep 1
./zhtserver -z zht.conf -n neighbor2.conf -p 50004 & sleep 1
./zhtserver -z zht.conf -n neighbor2.conf -p 50005 & sleep 1
./zhtserver -z zht.conf -n neighbor2.conf -p 50006 & sleep 1
./zhtserver -z zht.conf -n neighbor2.conf -p 50007 & sleep 1
./zhtserver -z zht.conf -n neighbor2.conf -p 50008 & sleep 1
