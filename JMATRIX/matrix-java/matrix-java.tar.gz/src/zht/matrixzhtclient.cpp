#include "../matrix_client_ZHTClient.h"

#include "cpp_zhtclient.h"

#include  <stdlib.h>
#include <string.h>

//#include "zpack.pb.h"
#include "ZHTUtil.h"
#include "ConfHandler.h"
#include "Env.h"
#include "StrTokenizer.h"

using namespace iit::datasys::zht::dm;

JNIEXPORT jstring JNICALL Java_matrix_client_ZHTClient_lookUp(JNIEnv *, jobject, jstring key) {
	string val;
	string val2;
	string result;
	int rc = ZHTClient::commonOp(Const::ZSC_OPC_LOOKUP, key, val, val2, result, 1);
	result = ZHTClient::extract_value(result);

	return result;
}

JNIEXPORT jint JNICALL Java_matrix_client_ZHTClient_insertZHT(JNIEnv *, jobject, jstring key, jstring val) {
	string val2;
	string result;
	int rc = ZHTClient::commonOp(Const::ZSC_OPC_INSERT, key, val, val2, result, 1);

	return rc;
}

JNIEXPORT jint JNICALL Java_matrix_client_ZHTClient_compareSwapInt(JNIEnv *, jobject, jstring key, jstring seen_val, jstring new_val) {

	string result;

	int rc = ZHTClient::commonOp(Const::ZSC_OPC_CMPSWP, key, seen_val, new_val, result, 1);

	return rc;
}

JNIEXPORT jstring JNICALL Java_matrix_client_ZHTClient_compareSwapString(JNIEnv *, jobject, jstring key, jstring seen_val, jstring new_val) {

	string result;

	int rc = ZHTClient::commonOp(Const::ZSC_OPC_CMPSWP, key, seen_val, new_val, result, 1);

	result = ZHTClient::extract_value(result);

	return rc;

}
